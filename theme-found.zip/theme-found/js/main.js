$(document).ready(function(){
	
  new WOW().init(); //Khởi tạo wow JS
});